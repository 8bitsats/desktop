import { TodoList } from '@/components/TodoList';

export default function Home() {
  return (
    <main className="container mx-auto">
      <TodoList />
    </main>
  );
}